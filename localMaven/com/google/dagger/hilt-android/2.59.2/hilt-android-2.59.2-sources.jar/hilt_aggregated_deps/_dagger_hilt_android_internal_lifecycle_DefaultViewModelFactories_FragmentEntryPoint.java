package hilt_aggregated_deps;

import dagger.hilt.processor.internal.aggregateddeps.AggregatedDeps;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@AggregatedDeps(
    components = "dagger.hilt.android.components.FragmentComponent",
    entryPoints = "dagger.hilt.android.internal.lifecycle.DefaultViewModelFactories.FragmentEntryPoint"
)
public class _dagger_hilt_android_internal_lifecycle_DefaultViewModelFactories_FragmentEntryPoint {
}
