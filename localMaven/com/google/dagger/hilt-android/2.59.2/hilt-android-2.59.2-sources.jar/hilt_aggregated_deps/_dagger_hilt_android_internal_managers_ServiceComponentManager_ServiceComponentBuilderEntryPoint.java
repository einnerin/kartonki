package hilt_aggregated_deps;

import dagger.hilt.processor.internal.aggregateddeps.AggregatedDeps;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@AggregatedDeps(
    components = "dagger.hilt.components.SingletonComponent",
    entryPoints = "dagger.hilt.android.internal.managers.ServiceComponentManager.ServiceComponentBuilderEntryPoint"
)
public class _dagger_hilt_android_internal_managers_ServiceComponentManager_ServiceComponentBuilderEntryPoint {
}
