package hilt_aggregated_deps;

import dagger.hilt.processor.internal.aggregateddeps.AggregatedDeps;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@AggregatedDeps(
    components = "dagger.hilt.android.components.ActivityComponent",
    modules = "dagger.hilt.android.internal.modules.HiltWrapper_ActivityModule"
)
public class _dagger_hilt_android_internal_modules_HiltWrapper_ActivityModule {
}
