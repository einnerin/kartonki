package hilt_aggregated_deps;

import dagger.hilt.processor.internal.aggregateddeps.AggregatedDeps;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@AggregatedDeps(
    components = "dagger.hilt.android.components.ActivityRetainedComponent",
    entryPoints = "dagger.hilt.android.internal.managers.ActivityComponentManager.ActivityComponentBuilderEntryPoint"
)
public class _dagger_hilt_android_internal_managers_ActivityComponentManager_ActivityComponentBuilderEntryPoint {
}
