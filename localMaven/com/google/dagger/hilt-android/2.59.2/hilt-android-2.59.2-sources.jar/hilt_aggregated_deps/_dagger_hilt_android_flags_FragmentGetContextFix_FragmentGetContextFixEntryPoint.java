package hilt_aggregated_deps;

import dagger.hilt.processor.internal.aggregateddeps.AggregatedDeps;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@AggregatedDeps(
    components = "dagger.hilt.components.SingletonComponent",
    entryPoints = "dagger.hilt.android.flags.FragmentGetContextFix.FragmentGetContextFixEntryPoint"
)
public class _dagger_hilt_android_flags_FragmentGetContextFix_FragmentGetContextFixEntryPoint {
}
