package hilt_aggregated_deps;

import dagger.hilt.processor.internal.aggregateddeps.AggregatedDeps;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@AggregatedDeps(
    components = "dagger.hilt.components.SingletonComponent",
    modules = "dagger.hilt.android.internal.modules.ApplicationContextModule"
)
public class _dagger_hilt_android_internal_modules_ApplicationContextModule {
}
