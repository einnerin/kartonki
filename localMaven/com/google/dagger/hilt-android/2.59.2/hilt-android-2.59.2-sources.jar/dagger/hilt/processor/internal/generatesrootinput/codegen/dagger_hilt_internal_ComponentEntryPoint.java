package dagger.hilt.processor.internal.generatesrootinput.codegen;

import dagger.hilt.internal.ComponentEntryPoint;
import dagger.hilt.internal.generatesrootinput.GeneratesRootInputPropagatedData;

/**
 * Generated class to get the list of annotations that generate input for root.
 */
@GeneratesRootInputPropagatedData(ComponentEntryPoint.class)
class dagger_hilt_internal_ComponentEntryPoint {
}
