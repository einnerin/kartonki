package dagger.hilt.processor.internal.definecomponent.codegen;

import dagger.hilt.internal.definecomponent.DefineComponentClasses;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@DefineComponentClasses(
    builder = "dagger.hilt.android.internal.builders.FragmentComponentBuilder"
)
public class _dagger_hilt_android_internal_builders_FragmentComponentBuilder {
}
