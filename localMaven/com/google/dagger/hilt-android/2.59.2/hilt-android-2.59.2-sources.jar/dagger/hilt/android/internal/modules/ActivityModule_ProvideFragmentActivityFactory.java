package dagger.hilt.android.internal.modules;

import android.app.Activity;
import androidx.fragment.app.FragmentActivity;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("dagger.Reusable")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ActivityModule_ProvideFragmentActivityFactory implements Factory<FragmentActivity> {
  private final Provider<Activity> activityProvider;

  private ActivityModule_ProvideFragmentActivityFactory(Provider<Activity> activityProvider) {
    this.activityProvider = activityProvider;
  }

  @Override
  public FragmentActivity get() {
    return provideFragmentActivity(activityProvider.get());
  }

  public static ActivityModule_ProvideFragmentActivityFactory create(
      Provider<Activity> activityProvider) {
    return new ActivityModule_ProvideFragmentActivityFactory(activityProvider);
  }

  public static FragmentActivity provideFragmentActivity(Activity activity) {
    return Preconditions.checkNotNullFromProvides(ActivityModule.provideFragmentActivity(activity));
  }
}
