package dagger.hilt.android.internal.managers;

import dagger.Module;
import dagger.hilt.InstallIn;
import dagger.hilt.android.components.ActivityRetainedComponent;
import dagger.hilt.codegen.OriginatingElement;

@OriginatingElement(
    topLevelClass = ActivityRetainedComponentManager.class
)
@InstallIn(ActivityRetainedComponent.class)
@Module(
    includes = ActivityRetainedComponentManager.LifecycleModule.class
)
public final class HiltWrapper_ActivityRetainedComponentManager_LifecycleModule {
}
