package dagger.hilt.android.internal.modules;

import android.app.Application;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ApplicationContextModule_ProvideApplicationFactory implements Factory<Application> {
  private final ApplicationContextModule module;

  private ApplicationContextModule_ProvideApplicationFactory(ApplicationContextModule module) {
    this.module = module;
  }

  @Override
  public Application get() {
    return provideApplication(module);
  }

  public static ApplicationContextModule_ProvideApplicationFactory create(
      ApplicationContextModule module) {
    return new ApplicationContextModule_ProvideApplicationFactory(module);
  }

  public static Application provideApplication(ApplicationContextModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideApplication());
  }
}
