package dagger.hilt.android.internal.modules;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("dagger.hilt.android.qualifiers.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ApplicationContextModule_ProvideContextFactory implements Factory<Context> {
  private final ApplicationContextModule module;

  private ApplicationContextModule_ProvideContextFactory(ApplicationContextModule module) {
    this.module = module;
  }

  @Override
  public Context get() {
    return provideContext(module);
  }

  public static ApplicationContextModule_ProvideContextFactory create(
      ApplicationContextModule module) {
    return new ApplicationContextModule_ProvideContextFactory(module);
  }

  public static Context provideContext(ApplicationContextModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideContext());
  }
}
