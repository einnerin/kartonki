package dagger.hilt.android.internal.managers;

import androidx.lifecycle.SavedStateHandle;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("dagger.hilt.android.scopes.ActivityRetainedScoped")
@QualifierMetadata("dagger.hilt.android.lifecycle.ActivityRetainedSavedState")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ActivitySavedStateHandleModule_ProvideSavedStateHandleFactory implements Factory<SavedStateHandle> {
  private final Provider<SavedStateHandleHolder> savedStateHandleHolderProvider;

  private ActivitySavedStateHandleModule_ProvideSavedStateHandleFactory(
      Provider<SavedStateHandleHolder> savedStateHandleHolderProvider) {
    this.savedStateHandleHolderProvider = savedStateHandleHolderProvider;
  }

  @Override
  public SavedStateHandle get() {
    return provideSavedStateHandle(savedStateHandleHolderProvider.get());
  }

  public static ActivitySavedStateHandleModule_ProvideSavedStateHandleFactory create(
      Provider<SavedStateHandleHolder> savedStateHandleHolderProvider) {
    return new ActivitySavedStateHandleModule_ProvideSavedStateHandleFactory(savedStateHandleHolderProvider);
  }

  public static SavedStateHandle provideSavedStateHandle(
      SavedStateHandleHolder savedStateHandleHolder) {
    return Preconditions.checkNotNullFromProvides(ActivitySavedStateHandleModule.provideSavedStateHandle(savedStateHandleHolder));
  }
}
