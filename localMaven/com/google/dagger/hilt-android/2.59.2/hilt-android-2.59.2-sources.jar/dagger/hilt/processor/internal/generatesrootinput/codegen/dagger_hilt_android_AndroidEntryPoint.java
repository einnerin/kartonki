package dagger.hilt.processor.internal.generatesrootinput.codegen;

import dagger.hilt.android.AndroidEntryPoint;
import dagger.hilt.internal.generatesrootinput.GeneratesRootInputPropagatedData;

/**
 * Generated class to get the list of annotations that generate input for root.
 */
@GeneratesRootInputPropagatedData(AndroidEntryPoint.class)
class dagger_hilt_android_AndroidEntryPoint {
}
