package dagger.hilt.android.internal.lifecycle;

import dagger.hilt.android.internal.builders.ViewModelComponentBuilder;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Map;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("dagger.hilt.android.internal.lifecycle.HiltViewModelMap.KeySet")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DefaultViewModelFactories_InternalFactoryFactory_Factory implements Factory<DefaultViewModelFactories.InternalFactoryFactory> {
  private final Provider<Map<Class<?>, Boolean>> keySetProvider;

  private final Provider<ViewModelComponentBuilder> viewModelComponentBuilderProvider;

  private DefaultViewModelFactories_InternalFactoryFactory_Factory(
      Provider<Map<Class<?>, Boolean>> keySetProvider,
      Provider<ViewModelComponentBuilder> viewModelComponentBuilderProvider) {
    this.keySetProvider = keySetProvider;
    this.viewModelComponentBuilderProvider = viewModelComponentBuilderProvider;
  }

  @Override
  public DefaultViewModelFactories.InternalFactoryFactory get() {
    return newInstance(keySetProvider.get(), viewModelComponentBuilderProvider.get());
  }

  public static DefaultViewModelFactories_InternalFactoryFactory_Factory create(
      Provider<Map<Class<?>, Boolean>> keySetProvider,
      Provider<ViewModelComponentBuilder> viewModelComponentBuilderProvider) {
    return new DefaultViewModelFactories_InternalFactoryFactory_Factory(keySetProvider, viewModelComponentBuilderProvider);
  }

  public static DefaultViewModelFactories.InternalFactoryFactory newInstance(
      Map<Class<?>, Boolean> keySet, ViewModelComponentBuilder viewModelComponentBuilder) {
    return new DefaultViewModelFactories.InternalFactoryFactory(keySet, viewModelComponentBuilder);
  }
}
