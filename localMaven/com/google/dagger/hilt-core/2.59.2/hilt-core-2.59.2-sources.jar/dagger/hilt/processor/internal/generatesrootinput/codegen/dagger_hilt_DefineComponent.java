package dagger.hilt.processor.internal.generatesrootinput.codegen;

import dagger.hilt.DefineComponent;
import dagger.hilt.internal.generatesrootinput.GeneratesRootInputPropagatedData;

/**
 * Generated class to get the list of annotations that generate input for root.
 */
@GeneratesRootInputPropagatedData(DefineComponent.class)
class dagger_hilt_DefineComponent {
}
