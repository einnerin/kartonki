package dagger.hilt.processor.internal.generatesrootinput.codegen;

import dagger.hilt.internal.generatesrootinput.GeneratesRootInputPropagatedData;
import dagger.hilt.migration.AliasOf;

/**
 * Generated class to get the list of annotations that generate input for root.
 */
@GeneratesRootInputPropagatedData(AliasOf.class)
class dagger_hilt_migration_AliasOf {
}
