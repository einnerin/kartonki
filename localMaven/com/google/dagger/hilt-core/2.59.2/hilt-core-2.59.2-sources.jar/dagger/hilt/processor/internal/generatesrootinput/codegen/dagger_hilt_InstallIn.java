package dagger.hilt.processor.internal.generatesrootinput.codegen;

import dagger.hilt.InstallIn;
import dagger.hilt.internal.generatesrootinput.GeneratesRootInputPropagatedData;

/**
 * Generated class to get the list of annotations that generate input for root.
 */
@GeneratesRootInputPropagatedData(InstallIn.class)
class dagger_hilt_InstallIn {
}
