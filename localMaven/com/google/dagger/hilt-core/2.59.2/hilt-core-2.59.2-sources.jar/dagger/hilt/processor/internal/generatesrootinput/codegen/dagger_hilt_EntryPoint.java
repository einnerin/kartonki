package dagger.hilt.processor.internal.generatesrootinput.codegen;

import dagger.hilt.EntryPoint;
import dagger.hilt.internal.generatesrootinput.GeneratesRootInputPropagatedData;

/**
 * Generated class to get the list of annotations that generate input for root.
 */
@GeneratesRootInputPropagatedData(EntryPoint.class)
class dagger_hilt_EntryPoint {
}
